/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
module.exports = function (grunt) {
    require('load-grunt-tasks')(grunt);
    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        concurrent:
        {
            target:
            {
                tasks: ["watch:autoprefixer", "watch:jscompressor", "watch:jshint"],
                options:{
                    logConcurrentOutput: true
                }
            }
        },
        autoprefixer:
        {
            options:
            {
               browsers: ['> 1% in PL', 'last 2 versions', 'ie 8']
            },
            dist:
            {
               src: 'css/style.css',
               dest: 'css/styleprefixed.css'
            }
        },
        watch:
        {
            autoprefixer:
            {
                files: 'css/style.css',
                tasks: ['autoprefixer', 'cssmin']
            },
            jscompressor:
            {
                files: ['js/*.js', '!js/output.min.js'],
                tasks: ['uglify']
            },
            jshint:
            {
                files: ['js/**/*.js', '!js/output.min.js'],
                tasks: ['jshint']
            }
        },
        cssmin:
        {
            target:
            {
                files:
                {
                    'css/styleprefixed.min.css': ['css/styleprefixed.css']
                }
            }
        },
        uglify:
        {
            target:
            {
                files:
                {
                    'js/output.min.js': ['js/script.js', 'js/script2.js']
                }
            }
        },
        imagemin:
        {
            dynamic:
            {
                options:
                {
                    optimizationLevel: 7
                },
                files:
                [
                    {
                       expand: true,
                       cwd: 'images/',
                       src: ['**/*.{jpg,png,gif}', '!build/**/*.{jpg,png,gif}'],
                       dest: 'images/build'
                    }
                ]
            }
        },
        jshint:
        {   
            options: {
                
            "bitwise": true, 
            "camelcase": true, 
            "curly": true, 
            "latedef": true, 
            "newcap": true,     
            "nonew": true,          
            "undef": true, 
            "unused": true,     
            "esnext": true,     
            
            "sub": true,  
            "browser": true, 
            "node": true, 
            "jquery": true, 
            "devel": true, 
            "strict": true   
          },
          target:
          {
            src: ['js/**/*.js', '!js/output.min.js']
          }
        }


    });

    grunt.registerTask("default", ['autoprefixer', 'watch']);
    grunt.registerTask("minifyNewImages", ['newer:imagemin']);

};

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
module.exports = function (grunt) {
    require('load-grunt-tasks')(grunt);
    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        autoprefixer:
        {
            options:
            {
               browsers: ['> 1% in PL', 'last 2 versions', 'ie 8']
            },
            dist:
            {
               src: 'css/style.css',
               dest: 'css/styleprefixed.css'
            }
        },
        watch:
        {
            autoprefixer:
            {
                files: 'css/style.css',
                tasks: ['autoprefixer', 'cssmin']
            },
            jscompressor:
            {
                files: 'js/*.js',
                tasks: ['uglify']
            },
            jshint:
            {
                files: ['js/**/*.js', '!js/output.min.js'],
                tasks: ['jshint']
            }
        },
        cssmin:
        {
            target:
            {
                files:
                {
                    'css/styleprefixed.min.css': ['css/styleprefixed.css']
                }
            }
        },
        uglify:
        {
            target:
            {
                files:
                {
                    'js/output.min.js': ['js/script.js', 'js/script2.js']
                }
            }
        },
        imagemin:
        {
            dynamic:
            {
                options:
                {
                    optimizationLevel: 7
                },
                files:
                [
                    {
                       expand: true,
                       cwd: 'images/',
                       src: ['**/*.{jpg,png,gif}', '!build/**/*.{jpg,png,gif}'],
                       dest: 'images/build'
                    }
                ]
            }
        },
        jshint:
        {   
            options: {
                
            "bitwise": true, //niemożność używania operatorów & i | - są rzadko używane, a często ktoś się myli
            "camelcase": true, //albo nazywasz zmienne takiSposob albo TAKI_SPOSOB, ale nie np. taki_sposob
            "curly": true, //wymagany curly bracer po pętli            
            "latedef": true, //nie można użyć zmiennej zanim się jej nie zdefinuje
            "newcap": true, //wymaganie pierwszej duzej litery w konstruktorach            
            "nonew": true,  //nie można stworzyć konstruktora bez przypisania go do niczego            
            "undef": true, //nie można użyć niezdefiniowanej zmiennej
            "unused": true, //informuje o tym, że stworzyliśmy zmienną, ale nie użyliśmy jej           
            "esnext": true, //piszemy zgodnie z najnowszą specyfikacją    
            
            "sub": true,  //nie wyrzuca ostrzeżenia dla person['name'] twierdzi, że lepiej jest napisać: person.name.
            "browser": true, //dzięki temu nie wyrzuca błędów dla globalnych zmiennych
            "node": true, //można bez problemu korzystać z node
            "jquery": true, //j/w ale z jquery
            "devel": true, //alert nie wyrzuca ostrzeżenia           
            "strict": true // - pisanie w strict mode, jak się zrobi pewnego rodzaju "ciche" błędy to program normalnie, działa, z tym nie      
          },
          target:
          {
            src: ['js/**/*.js', '!js/output.min.js']
          }
        }


    });

    grunt.registerTask("default", ['autoprefixer', 'watch']);
    grunt.registerTask("minifyNewImages", ['newer:imagemin']);

};

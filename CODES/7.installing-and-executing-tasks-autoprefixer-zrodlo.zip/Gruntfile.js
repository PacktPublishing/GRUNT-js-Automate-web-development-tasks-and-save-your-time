/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
module.exports = function (grunt) {
    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
          autoprefixer: {
            options: {
              // Task-specific options go here. 
            },
            dist: {
               src: 'css/style.css',
               dest: 'css/styleprefixed.css'
            }
          }
    });
    
    grunt.loadNpmTasks("grunt-autoprefixer");
    
    grunt.registerTask("default", ['autoprefixer']);
    
    //grunt.registerTask("ownNameOfTask", "Adding vendor prefixes and then do sth else", ['autoprefixer']);
    
};
